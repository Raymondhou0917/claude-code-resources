#!/bin/bash
set -euo pipefail
RES="$(cd "$(dirname "$0")" && pwd)"
WORKDIR="$(mktemp -d "${TMPDIR:-/tmp}/shifu-ai-env.XXXXXX")"
cp "$RES/install-mac.sh" "$WORKDIR/install-mac.sh"
chmod +x "$WORKDIR/install-mac.sh"
cat > "$WORKDIR/安裝.command" <<EOF
#!/bin/bash
cd "$WORKDIR"
if [[ "\$(uname -m)" == "arm64" ]]; then
  arch -arm64 ./install-mac.sh
else
  ./install-mac.sh
fi
EOF
chmod +x "$WORKDIR/安裝.command"
open "$WORKDIR/安裝.command"
